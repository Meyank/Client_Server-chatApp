package com.yash.cms.serviceimp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.yash.cms.daoimp.MenuFetchingDao;

public class MainMenuFetchingService {
	/**
	 * reference to dao class menu fetching
	 */
	MenuFetchingDao menuFetchingDaoObj;
	/**
	 * object to that dao class is created here in its constructor
	 */
	public MainMenuFetchingService() {
		menuFetchingDaoObj = new MenuFetchingDao();

	}

	/**
	 * this will accept & return the courses in the database by calling dao
	 * coursesFetchDao method
	 * 
	 * @return
	 */
	public List<String> keyGeneration() {
		List<String> coursesFromDataBase = menuFetchingDaoObj.coursesFetchDao();
		return coursesFromDataBase;
	}

	/**
	 * * this will accept & return the main title in the database by calling dao
	 * mainTitleFetchDao method
	 * 
	 * @param string
	 * 
	 * @return
	 */
	public List<String> mainTitleGeneration(String courseName) {
		List<String> mainTitleFromDataBase = menuFetchingDaoObj.mainTitleFetchDao(courseName);
		return mainTitleFromDataBase;
	}

	public Map<String, List<String>> menudata() {
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		ArrayList<String> courses = (ArrayList<String>) keyGeneration();
		for (String courseName : courses) {
			map.put(courseName, mainTitleGeneration(courseName));
		}
		return map;
	}

}
