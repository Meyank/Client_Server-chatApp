package com.yash.cms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.util.MainTitleDataUtility;

@WebServlet("/mt")
public class SubtitleController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		String selectedCourse = request.getParameter("course");
		
		Map<String, List<String>> map = MainTitleDataUtility.mainMenuData();
		List<String> valuesForSelected =extractMainTitleValues(selectedCourse, map);
		response.setContentType("text/html");
		pw.println("<html>");
		pw.println("<head>");
		pw.println("<title>subtitle Upload</title>");
		pw.println("</head>");
		pw.println("<body>");
		pw.println("<fieldset style='width: 20%;       margin: 0 auto;'>");
		pw.println("<legend>Choose Main Course </legend>");
		pw.println("<select >");
    
				int i=0;
				while (i<valuesForSelected.size()) {
					pw.println("<option value ='java'>" + valuesForSelected.get(i) + "</option>");
				i++;}
				pw.println(" </select>");
				pw.println("</fieldset>");
				pw.println("</body>");
				pw.println("</html>");
	}
	
	
	private List<String> extractMainTitleValues(String course, Map<String, List<String>> map)
	{
		for (Map.Entry<String, List<String>> entry : map.entrySet()) {
			String key = entry.getKey();
			if (key.equalsIgnoreCase(course)) {
				List<String> values = entry.getValue();
				return values;
				}
			}return  null;
	}

		

	}
