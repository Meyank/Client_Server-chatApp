package com.yash.cms.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.util.Dbutil;

public class MenuFetchingDao {
	Connection con;
/**
 * in constructor an object to dbutil class is created and get connection method of dbutil
 * is called to get connection
 */
	public MenuFetchingDao() {
		Dbutil dbUtilObj = new Dbutil();
		con = dbUtilObj.getConnection("jdbc:mysql://localhost:3306/subtitle", "root", "root");
	}
/**
 * this is to fetch the courses from database and saved in arraylist and returned to service
 * @return
 */
	public List<String> coursesFetchDao() {
		String fetchMenu = "select course,maintitle from details GROUP BY course";
		List<String> coursesList = new ArrayList<String>();
		try {
			Statement stmt = con.prepareStatement(fetchMenu);

			ResultSet rs = stmt.executeQuery(fetchMenu);
			while (rs.next()) {
				String courses = rs.getString("course");
				coursesList.add(courses);
				return coursesList;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
/**
 * this is to fetch the maintitles from database and saved in arraylist and returned to service
 * @return
 */
	public List<String> mainTitleFetchDao(String courseName) {
		String fetchMenuQry = "select maintitle from details where course = ? GROUP BY maintitle";
		List<String> mainTitles = new ArrayList<String>();
		try {
			PreparedStatement pstmt = con.prepareStatement(fetchMenuQry);
                pstmt.setString(1, courseName);
			ResultSet rs = pstmt.executeQuery(fetchMenuQry);
			while (rs.next()) {
				String courses = rs.getString("maintitle");
				mainTitles.add(courses);
				return mainTitles;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}