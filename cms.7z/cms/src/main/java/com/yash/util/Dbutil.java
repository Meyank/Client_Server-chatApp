package com.yash.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * this is db utility class to get connection from database.
 * 
 * @author mayank
 *
 */
public class Dbutil {

	/**
	 * here in constructor driver class is getiing loaded
	 * 
	 * @param driverName
	 * @throws ClassNotFoundException
	 */

	public Dbutil(String driverName) {
		try {
			Class c = Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
	}

	public Dbutil() {
	}

	/**
	 * this method is to get and return connection with database
	 * 
	 * @param url
	 * @param userName
	 * @param pass
	 * @return
	 */
	public Connection getConnection(String url, String userName, String pass) {
		Connection con;
		try {
			con = DriverManager.getConnection(url, userName, pass);
			return con;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

}
