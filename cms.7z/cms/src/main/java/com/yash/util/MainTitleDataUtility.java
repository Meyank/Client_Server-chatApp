package com.yash.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class MainTitleDataUtility {
	
	public static Map<String, List<String>> mainMenuData() {
	
	Map<String, List<String>> map = new HashMap<String, List<String>>();
	
	
	List<String> javaMainTitles = new ArrayList<String>();
	javaMainTitles.add("oops");
	javaMainTitles.add("file i/o");
	
    List<String> htmlMainTitles = new ArrayList<String>();
    htmlMainTitles.add("css");
    htmlMainTitles.add("jss");
    map.put("java", javaMainTitles);
    map.put("html", htmlMainTitles);
	return map;
	}
}
