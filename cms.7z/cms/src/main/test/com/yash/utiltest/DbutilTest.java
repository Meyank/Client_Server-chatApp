package com.yash.utiltest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;

import com.yash.util.Dbutil;

/**
 * this is test case to test various database utilities
 * 
 * @author mayank
 *
 */
public class DbutilTest {

	/**
	 * this is to test/load the drivers
	 */
	@Before
	@Test
	public void test_for_Driver() {

		Dbutil dbUtil = new Dbutil("com.mysql.jdbc.Driver");

	}

	/**
	 * here the Connection to db is tested and the name of the db is matched
	 * with expected to check whether we are connected to right d.b
	 */
	@Test
	public void test_For_Connection() {
		/**
		 * url is to give the link to the database
		 */
		String url = "jdbc:mysql://localhost:3306/subtitle";
		/**
		 * username of the database
		 */
		String userName = "root";
		/**
		 * password to that database
		 */
		String pass = "root";
		Dbutil dbUtil = new Dbutil();
		Connection con = dbUtil.getConnection(url, userName, pass);
		/**
		 * in dbName the name of the database is taken with catalog method
		 */
		String dbName;
		try {
			dbName = con.getCatalog();
			assertEquals("subtitle", dbName);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}